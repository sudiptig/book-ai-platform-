def summarize(text):
    return text[:150] + "..."

def classify_genre(text):
    if "love" in text.lower():
        return "Romance"
    elif "war" in text.lower():
        return "History"
    else:
        return "Fiction"

def recommend(title):
    return f"If you like {title}, you may also like 'Atomic Habits'"