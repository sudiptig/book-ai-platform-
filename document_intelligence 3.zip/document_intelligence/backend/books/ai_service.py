import requests # type: ignore

LM_STUDIO_URL = "http://localhost:1234/v1/chat/completions"

def generate_summary(text):
    response = requests.post(
        LM_STUDIO_URL,
        json={
            "model": "local-model",  # replace with your model name
            "messages": [
                {"role": "user", "content": f"Summarize this book:\n{text}"}
            ],
            "temperature": 0.7
        }
    )

    return response.json()['choices'][0]['message']['content']


def classify_genre(text):
    response = requests.post(
        LM_STUDIO_URL,
        json={
            "model": "local-model",
            "messages": [
                {"role": "user", "content": f"Give the genre of this book:\n{text}"}
            ],
            "temperature": 0.3
        }
    )

    return response.json()['choices'][0]['message']['content']