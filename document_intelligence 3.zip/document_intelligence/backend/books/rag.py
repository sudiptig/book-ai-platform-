import chromadb
from sentence_transformers import SentenceTransformer
import requests

model = SentenceTransformer('all-MiniLM-L6-v2')

client = chromadb.Client()
collection = client.get_or_create_collection(name="books")

def chunk_text(text, size=300):
    return [text[i:i+size] for i in range(0, len(text), size)]

def add_book_to_db(book):
    chunks = chunk_text(book.description)

    for i, chunk in enumerate(chunks):
        embedding = model.encode(chunk).tolist()

        collection.add(
            documents=[chunk],
            embeddings=[embedding],
            ids=[f"{book.id}_{i}"]
        )

def query_books(question):
    q_embedding = model.encode(question).tolist()

    results = collection.query(
        query_embeddings=[q_embedding],
        n_results=3
    )

    return results['documents'][0]

def call_llm(prompt):
    try:
        response = requests.post(
            "http://localhost:1234/v1/chat/completions",
            json={
                "model": "mistral",
                "messages": [
                    {"role": "user", "content": prompt}
                ],
                "temperature": 0.7
            }
        )

        return response.json()['choices'][0]['message']['content']

    except Exception as e:
        return f"Error connecting to LLM: {str(e)}"

def ask_question_rag(question):
    docs = query_books(question)
    context = " ".join(docs)

    prompt = f"""
    You are a helpful AI.

    Use ONLY the context below to answer.
If answer not found, say "Not found in book".

Context:
{context}

Question:
{question}

Also mention source context.
"""