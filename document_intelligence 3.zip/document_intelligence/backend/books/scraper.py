from selenium import webdriver
from .models import Book

def scrape_books():
    driver = webdriver.Chrome()
    driver.get("https://books.toscrape.com/")

    books = driver.find_elements("class name", "product_pod")

    for b in books[:10]:
        title = b.find_element("tag name", "h3").text

        Book.objects.create(
            title=title,
            description="Sample scraped book",
            rating=4.0,
            url="https://books.toscrape.com/"
        )

    driver.quit()