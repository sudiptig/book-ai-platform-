from django.db import models

class Book(models.Model):
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255, default="Unknown")
    description = models.TextField()
    rating = models.FloatField(null=True, blank=True)
    url = models.URLField()

    def __str__(self):
        return self.title
class ChatHistory(models.Model):
    question = models.TextField()
    answer = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)   