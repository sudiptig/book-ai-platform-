from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

model = SentenceTransformer('all-MiniLM-L6-v2')

docs = []
metadata = []

dimension = 384
index = faiss.IndexFlatIP(dimension)


def add_document(text, meta=None):
    global docs, metadata, index

    emb = model.encode([text]).astype("float32")
    faiss.normalize_L2(emb)

    index.add(emb)

    docs.append(text)
    metadata.append(meta)


def search_similar(query, k=3):
    global docs, metadata, index

    if len(docs) == 0:
        return []

    q_emb = model.encode([query]).astype("float32")
    faiss.normalize_L2(q_emb)

    distances, indices = index.search(q_emb, k)

    results = []

    for i in indices[0]:
        if 0 <= i < len(docs):
            results.append({
                "text": docs[i],
                "meta": metadata[i]
            })

    return results