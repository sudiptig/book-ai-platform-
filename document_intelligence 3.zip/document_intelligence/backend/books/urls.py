from django.urls import path
from . import views
from django.http import HttpResponse

def home(request):
    return HttpResponse("Backend is running 🚀")
urlpatterns = [
    path('', home),
    path('chat/', views.chat_history),
    path('ask/', views.ask_question),
    path('books/', views.get_books),
]