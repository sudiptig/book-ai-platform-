from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.shortcuts import get_object_or_404

from .models import Book, ChatHistory
from .serializers import BookSerializer
from .rag import ask_question_rag


# ---------------------------
# GET ALL BOOKS
# ---------------------------
@api_view(['GET'])
def get_books(request):
    books = Book.objects.all()
    serializer = BookSerializer(books, many=True)
    return Response(serializer.data)


# ---------------------------
# GET BOOK DETAIL
# ---------------------------
@api_view(['GET'])
def get_book_detail(request, id):
    book = get_object_or_404(Book, id=id)
    serializer = BookSerializer(book)
    return Response(serializer.data)


# ---------------------------
# UPLOAD BOOK
# ---------------------------
@api_view(['POST'])
def upload_book(request):
    serializer = BookSerializer(data=request.data)

    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)

    return Response(serializer.errors)


# ---------------------------
# ASK QUESTION (RAG + SAVE CHAT)
# ---------------------------
@api_view(['POST'])
def ask_question(request):
    question = request.data.get("question")

    if not question or not question.strip():
        return Response({"error": "Question is required"})

    question = question.strip()

    answer = ask_question_rag(question)

    # Save to DB
    ChatHistory.objects.create(
        question=question,
        answer=answer
    )

    return Response({
        "question": question,
        "answer": answer
    })


# ---------------------------
# CHAT HISTORY (LAST 10)
# ---------------------------
@api_view(['GET'])
def chat_history(request):
    chats = ChatHistory.objects.all().order_by('-id')[:10]

    return Response([
        {
            "question": c.question,
            "answer": c.answer
        }
        for c in chats
    ])