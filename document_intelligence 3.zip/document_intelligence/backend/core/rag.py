from sentence_transformers import SentenceTransformer
import chromadb
import uuid

# Load embedding model once
model = SentenceTransformer("all-MiniLM-L6-v2")

# Persistent vector DB
client = chromadb.PersistentClient(path="./chroma_db")

collection = client.get_or_create_collection(
    name="documents"
)


def add_document(text: str, metadata: dict = None):
    doc_id = str(uuid.uuid4())

    embedding = model.encode(text).tolist()

    collection.add(
        ids=[doc_id],
        embeddings=[embedding],
        documents=[text],
        metadatas=[metadata or {}]
    )

    return doc_id


def search_similar(query: str, top_k: int = 5):
    query_embedding = model.encode(query).tolist()

    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k
    )

    return results["documents"][0] if results["documents"] else []