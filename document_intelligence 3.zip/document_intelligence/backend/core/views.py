from rest_framework.decorators import api_view
from rest_framework.response import Response

from .models import Book
from .serializers import BookSerializer
from .ai import generate_summary, classify_genre
from .rag import add_document, search_similar


@api_view(['GET', 'POST'])
def books(request):

    if request.method == 'GET':
        data = Book.objects.all()
        serializer = BookSerializer(data, many=True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = BookSerializer(data=request.data)

        if serializer.is_valid():
            book = serializer.save()

            book.summary = generate_summary(book.description)
            book.genre = classify_genre(book.description)
            book.save()

            return Response(BookSerializer(book).data)

        return Response(serializer.errors, status=400)


@api_view(['POST'])
def add_book_to_rag(request):
    text = request.data.get("text")
    add_document(text)
    return Response({"message": "Added to vector DB"})


@api_view(['POST'])
def ask_question(request):
    question = request.data.get("question")

    docs = search_similar(question)
    context = "\n".join(docs)

    answer = generate_summary(context + "\n\nQuestion: " + question)

    return Response({
        "question": question,
        "answer": answer,
        "context": docs
    })