import { useState, useEffect } from "react";
import axios from "axios";

function Ask() {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [history, setHistory] = useState([]);

  const fetchHistory = async () => {
    const res = await axios.get("http://127.0.0.1:8001/chat/");
    setHistory(res.data);
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const ask = async () => {
    const res = await axios.post("http://127.0.0.1:8001/ask/", {
      question
    });

    setAnswer(res.data.answer);

    // IMPORTANT: refresh history after ask
    fetchHistory();
  };

  return (
    <div className="mt-10 text-center">

      <input
        className="border p-3 w-1/2"
        onChange={(e) => setQuestion(e.target.value)}
        placeholder="Ask about books..."
      />

      <button onClick={ask} className="bg-blue-500 text-white p-3 ml-2">
        Ask
      </button>

      <div className="mt-5 font-bold">{answer}</div>

      <h2 className="mt-8 font-bold">🕘 Chat History</h2>

      {history.map((h, i) => (
        <div key={i} className="border p-2 m-2">
          <p><b>Q:</b> {h.question}</p>
          <p><b>A:</b> {h.answer}</p>
        </div>
      ))}
    </div>
  );
}

export default Ask;