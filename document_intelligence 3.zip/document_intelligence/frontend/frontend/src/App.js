import { useEffect, useState } from "react";
import axios from "axios";
import Ask from "./Ask";

function App() {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    axios.get("http://127.0.0.1:8001/books/")
      .then(res => setBooks(res.data));
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-4xl font-bold text-center mb-6">
        📚 Book Intelligence Platform
      </h1>

      <div className="grid md:grid-cols-3 gap-4">
        {books.map(b => (
          <div key={b.id} className="bg-white p-4 rounded-2xl shadow">
            <h2 className="text-xl font-semibold">{b.title}</h2>
            <p className="text-gray-600 text-sm mt-2">
              {b.description.slice(0, 100)}...
            </p>
          </div>
        ))}
      </div>

      <Ask />
    </div>
  );
}

export default App;